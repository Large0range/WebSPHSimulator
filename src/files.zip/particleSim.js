import * as THREE from 'three';
import { GPUComputationRenderer } from 'three/examples/jsm/misc/GPUComputationRenderer.js';

// Matches the constants from the original CPU particle.js
const H = 20;
const MASS = 1;
const STIFFNESS = 100;
const REST_DENSITY = 0.0109;
const VISCOSITY = 60;
const DT = 0.008;
const BOUNDS = 100;
const DENSITY_CONSTANT = 4 / (Math.PI * Math.pow(H, 8));

export async function initSimulation(renderer, particlesPerAxis) {
    const WIDTH = particlesPerAxis;
    const HEIGHT = particlesPerAxis;

    const gpuCompute = new GPUComputationRenderer(WIDTH, HEIGHT, renderer);

    const posVelTexture = gpuCompute.createTexture();
    const densityTexture = gpuCompute.createTexture();

    // Initial layout: matches createParticles() in particle.js (20x20 grid, spacing 10)
    const pvData = posVelTexture.image.data;
    const spacing = 10;
    let i = 0;
    for (let y = -10; y < 10; y++) {
        for (let x = -10; x < 10; x++) {
            const s = i * 4;
            pvData[s]     = x * spacing; // position.x
            pvData[s + 1] = y * spacing; // position.y
            pvData[s + 2] = 0;           // velocity.x
            pvData[s + 3] = 0;           // velocity.y
            i++;
        }
    }

    // Seed with restDensity so the very first frame (before density has actually
    // been computed from positions) starts from a sane value, not zero.
    const densityData = densityTexture.image.data;
    for (let d = 0; d < WIDTH * HEIGHT; d++) {
        densityData[d * 4] = REST_DENSITY;
    }

    let densitySrc = (await import('./density.glsl?raw')).default;
    let posVelSrc = (await import('./posvel.glsl?raw')).default;

    // Bake grid size in as compile-time constants (GLSL loop bounds must be constant)
    densitySrc = densitySrc.replace(/PARTICLES_WIDTH/g, WIDTH).replace(/PARTICLES_HEIGHT/g, HEIGHT);
    posVelSrc = posVelSrc.replace(/PARTICLES_WIDTH/g, WIDTH).replace(/PARTICLES_HEIGHT/g, HEIGHT);

    const densityVar = gpuCompute.addVariable('textureDensity', densitySrc, densityTexture);
    const posVelVar = gpuCompute.addVariable('texturePosVel', posVelSrc, posVelTexture);

    // density depends on last frame's positions; posVel depends on itself + the density just computed
    gpuCompute.setVariableDependencies(densityVar, [posVelVar]);
    gpuCompute.setVariableDependencies(posVelVar, [posVelVar, densityVar]);

    const texSize = new THREE.Vector2(WIDTH, HEIGHT);

    Object.assign(densityVar.material.uniforms, {
        h: { value: H },
        mass: { value: MASS },
        densityConstant: { value: DENSITY_CONSTANT },
        texSize: { value: texSize },
    });

    Object.assign(posVelVar.material.uniforms, {
        h: { value: H },
        mass: { value: MASS },
        stiffness: { value: STIFFNESS },
        restDensity: { value: REST_DENSITY },
        viscosity: { value: VISCOSITY },
        dt: { value: DT },
        bounds: { value: BOUNDS },
        texSize: { value: texSize },
    });

    const error = gpuCompute.init();
    if (error !== null) console.error(error);

    return { gpuCompute, posVelVar, densityVar, WIDTH, HEIGHT };
}
